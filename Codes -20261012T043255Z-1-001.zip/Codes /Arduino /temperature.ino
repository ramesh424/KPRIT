
const int moisturePin = A0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  int moistureValue = analogRead(moisturePin);

  // Basic estimate; calibrate for your sensor
  int moisturePercent = map(moistureValue, 1023, 0, 0, 100);
  moisturePercent = constrain(moisturePercent, 0, 100);

  Serial.print("Moisture Raw: ");
  Serial.print(moistureValue);

  Serial.print(" | Moisture: ");
  Serial.print(moisturePercent);
  Serial.println("%");

  delay(1000);
}
