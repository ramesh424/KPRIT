
#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "ssd";
const char* password = "1234567789";

const int ledPin = 2;  // D2 / GPIO 2

WebServer server(80);

void handleRoot() {
  String page = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ESP32 LED Control</title>
  </head>
  <body style="font-family:Arial;text-align:center;margin-top:50px">
    <h1>ESP32 Wi-Fi LED Control</h1>
    <p><a href="/on"><button style="font-size:24px;padding:15px">LED ON</button></a></p>
    <p><a href="/off"><button style="font-size:24px;padding:15px">LED OFF</button></a></p>
  </body>
  </html>
  )rawliteral";

  server.send(200, "text/html", page);
}

void setup() {
  Serial.begin(115200);

  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  Serial.print("Connecting to hotspot");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("Wi-Fi connected!");
  Serial.print("Open this IP address: http://");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);

  server.on("/on", []() {
    digitalWrite(ledPin, HIGH);
    server.sendHeader("Location", "/");
    server.send(303);
  });

  server.on("/off", []() {
    digitalWrite(ledPin, LOW);
    server.sendHeader("Location", "/");
    server.send(303);
  });

  server.begin();
  Serial.println("Web server started");
}

void loop() {
  server.handleClient();
}
