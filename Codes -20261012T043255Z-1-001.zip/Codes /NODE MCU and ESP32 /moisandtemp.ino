
#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>

const char* ssid = "ssd";
const char* password = "1234567789";

#define DHTPIN 4
#define DHTTYPE DHT11
#define MOISTURE_PIN 34

DHT dht(DHTPIN, DHTTYPE);
WebServer server(80);

void handleRoot() {
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  int moistureRaw = analogRead(MOISTURE_PIN);

  // Initial estimate; calibrate using dry and wet soil readings
  int moisturePercent = map(moistureRaw, 4095, 0, 0, 100);
  moisturePercent = constrain(moisturePercent, 0, 100);

  String page = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="3">
    <title>ESP32 Sensor Monitoring</title>
  </head>
  <body style="font-family:Arial;text-align:center;background:#eef5ee;padding:20px">
    <h1>ESP32 Sensor Monitoring</h1>
  )rawliteral";

  if (isnan(temperature) || isnan(humidity)) {
    page += "<p>DHT11 reading failed. Check VCC, DATA on D4, and GND.</p>";
  } else {
    page += "<h2>Temperature: " + String(temperature, 1) + " &deg;C</h2>";
    page += "<h2>Air Humidity: " + String(humidity, 1) + " %</h2>";
  }

  page += "<h2>Soil Moisture: " + String(moisturePercent) + " %</h2>";
  page += "<p>Raw moisture value: " + String(moistureRaw) + "</p>";
  page += "<p>Page refreshes every 3 seconds</p>";
  page += "</body></html>";

  server.send(200, "text/html", page);
}

void setup() {
  Serial.begin(115200);

  dht.begin();
  analogReadResolution(12);
  analogSetPinAttenuation(MOISTURE_PIN, ADC_11db);

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  Serial.print("Connecting to hotspot");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWi-Fi connected!");
  Serial.print("Website IP: http://");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.begin();

  Serial.println("Web server started");
}

void loop() {
  server.handleClient();
}
